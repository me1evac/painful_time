#version 150
#moj_import <fog.glsl>
uniform vec4 ColorModulator;
uniform float FogStart;
uniform float FogEnd;
uniform float GameTime;
uniform vec4 FogColor;
in float vertexDistance;
in vec4 vertexColor;
out vec4 fragColor;
void main() {
	float redValue = (255/255);
	float greenValue = (255/255);
	float blueValue = (255/255);
        fragColor = vec4(redValue * redValue, greenValue * greenValue, blueValue * blueValue, 1.0);
}
